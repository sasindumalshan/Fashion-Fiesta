package lk.ijse.fashionfiesta.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import lk.ijse.fashionfiesta.utill.Navigation;

import java.io.IOException;

public class LoginFormController {
    public Button btnLogin;

    @FXML
    void LoginOnAction(ActionEvent event) throws IOException {
        Navigation.switchNavigation("DashboardForm.fxml",event);
    }
}
