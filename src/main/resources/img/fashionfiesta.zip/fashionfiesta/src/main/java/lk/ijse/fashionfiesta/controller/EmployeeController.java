package lk.ijse.fashionfiesta.controller;

import javafx.event.ActionEvent;
import javafx.scene.input.MouseEvent;
import lk.ijse.fashionfiesta.utill.Navigation;

import java.io.IOException;

public class EmployeeController {
    public void btnEmployeeOnAction(MouseEvent mouseEvent) {
    }

    public void btnHomeOnAction(ActionEvent actionEvent) {
        try {
            Navigation.switchNavigation("DashboardForm.fxml",actionEvent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
