package lk.ijse.fashionfiesta.controller;

public class SalaryFormController {
}
