package lk.ijse.fashionfiesta.model;

public class CustomerModel {

}
