package lk.ijse.fashionfiesta.controller;


import javafx.scene.input.MouseEvent;
import lk.ijse.fashionfiesta.utill.Navigation;

import java.io.IOException;

public class DashboardController {


    public void Employee(javafx.scene.input.MouseEvent mouseEvent) {
        try {
            Navigation.switchNavigation("EmployeeForm.fxml",mouseEvent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void custo(MouseEvent mouseEvent) {
    }
}
