package lk.ijse.fashionfiesta.dto;

public class Customer {
}
