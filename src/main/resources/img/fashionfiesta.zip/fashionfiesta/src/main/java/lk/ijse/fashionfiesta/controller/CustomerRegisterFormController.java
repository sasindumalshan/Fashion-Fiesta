package lk.ijse.fashionfiesta.controller;

import javafx.event.ActionEvent;
import javafx.scene.input.MouseEvent;

public class CustomerRegisterFormController {
    public void btnEmployeeOnAction(MouseEvent mouseEvent) {
    }

    public void btnHomeOnAction(ActionEvent actionEvent) {
    }
}
