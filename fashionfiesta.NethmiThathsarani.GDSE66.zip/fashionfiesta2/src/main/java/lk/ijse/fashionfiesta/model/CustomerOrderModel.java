package lk.ijse.fashionfiesta.model;

import lk.ijse.fashionfiesta.db.DBConnection;
import lk.ijse.fashionfiesta.dto.CustomerOrder;
import lk.ijse.fashionfiesta.dto.CustomerOrderDetails;
import lk.ijse.fashionfiesta.utill.CrudUtil;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class CustomerOrderModel {
    public static boolean addCusOrder(CustomerOrder cusOrder) throws SQLException, ClassNotFoundException {
        return CrudUtil.crudUtil("INSERT INTO customer_order VALUES(?,?,?,?,?)",
                cusOrder.getCustomer_id(),
                cusOrder.getCustomer_order_id(),
                cusOrder.getCustomer_order_date(),
                cusOrder.getCustomer_order_time(),
                cusOrder.getPayment()
        );
    }

    public static ArrayList<String> getAll() throws SQLException, ClassNotFoundException {
        ResultSet set = CrudUtil.crudUtil("SELECT customer_order_id FROM customer_order ORDER BY LENGTH(customer_order_id),customer_order_id");
        ArrayList<String> list = new ArrayList<>();

        while (set.next()) {
            list.add(set.getString(1));
        }
        return list;
    }

    public static CustomerOrder get(String id) throws SQLException, ClassNotFoundException {
        CustomerOrder cusOrder=new CustomerOrder();
        ResultSet set = CrudUtil.crudUtil("SELECT * from customer_order where customer_id=?", id);
        if (set.next()){
            cusOrder.setCustomer_id(set.getString(1));
            cusOrder.setCustomer_order_id(set.getString(2));
            cusOrder.setCustomer_order_date(set.getString(3));
            cusOrder.setCustomer_order_time(set.getString(4));
            cusOrder.setPayment(set.getString(5));

        }
        return cusOrder;
    }

    public static boolean update(CustomerOrder cusOrder) throws SQLException, ClassNotFoundException {
        return CrudUtil.crudUtil("UPDATE customer_order SET customer_order_time=?,customer_order_date=?,customer_order_id=? WHERE customer_id=?",
                cusOrder.getCustomer_id(),
                cusOrder.getCustomer_order_id(),
                cusOrder.getCustomer_order_date(),
                cusOrder.getPayment()

        );
    }
    public static boolean remove(String customer_id) throws SQLException, ClassNotFoundException {
        return CrudUtil.crudUtil("DELETE FROM customer_order WHERE supplier_id=?",customer_id);
    }

    public static boolean addCustomerOrderDetails(CustomerOrderDetails details) throws SQLException, ClassNotFoundException {
        System.out.println(details.getCustomer_order_id());
        return CrudUtil.crudUtil("INSERT INTO customer_order_details VALUES(?,?,?,?)",
                details.getCustomer_order_id(),
                details.getItem_id(),
                details.getQuantity(),
                details.getPrice()
        );
    }

    public static boolean placeOrder(CustomerOrder cusOrder, CustomerOrderDetails details) {
//        Connection connection = null;
//        try {
//            connection = DBConnection.getInstance().getConnection();
//            connection.setAutoCommit(false);
//
//            if (CustomerOrderModel.addCusOrder(cusOrder)){
//                System.out.println("1");
//                if (CustomerOrderModel.addCustomerOrderDetails(details)){
//                    if (StockModel.CustomerOrderupdateData(details)){
//                        connection.commit();
//                        return true;
//                    }else {
//                        connection.rollback();
//                        return false;
//                    }
//
//                }else {
//                    System.out.println("2");
//                    connection.rollback();
//                    return false;
//                }
//            }else {
//                connection.rollback();
//                return false;
//            }
//
//        } catch (ClassNotFoundException | SQLException e) {
//            e.printStackTrace();
//        }finally {
//            try {
//                connection.setAutoCommit(true);
//            } catch (SQLException throwables) {
//                throwables.printStackTrace();
//            }
//        }
        Connection connection = null;
        try {
             connection = DBConnection.getInstance().getConnection();
            connection.setAutoCommit(false);

            if (CustomerOrderModel.addCusOrder(cusOrder)){
                System.out.println("1");
                if (CustomerOrderModel.addCustomerOrderDetails(details)){
                    System.out.println("2");
                    if (StockModel.CustomerOrderupdateData(details)){
                        System.out.println("3");
                        connection.commit();
                    }else {
                        System.out.println("3-else");
                        connection.rollback();
                        return false;
                    }
                }else {
                    System.out.println("2-else");
                    connection.rollback();
                    return false;
                }

            }else {
                System.out.println("1-else");
                connection.rollback();
                return false;
            }
        } catch (ClassNotFoundException | SQLException e) {
            throw new RuntimeException(e);
        }
        return true;
    }

    public static ArrayList<String> getSearchIds(String id) throws SQLException, ClassNotFoundException {
        ArrayList<String>ids=new ArrayList<>();
        ResultSet set=CrudUtil.crudUtil("SELECT customer_id from customer_order where customer_id LIKE ? or customer_order_id LIKE ? or customer_order_date LIKE ?",id+"%",id+"%",id+"%");
        while (set.next()){
            ids.add(set.getString(1));
        }
        return ids ;
    }

    public static String getCustOrder() throws SQLException, ClassNotFoundException {
        ResultSet set= CrudUtil.crudUtil("SELECT COUNT(customer_order_id) FROM customer_order");
        String count=null;
        if (set.next()){
            count=set.getString(1);
        }
        return count;
    }

}
