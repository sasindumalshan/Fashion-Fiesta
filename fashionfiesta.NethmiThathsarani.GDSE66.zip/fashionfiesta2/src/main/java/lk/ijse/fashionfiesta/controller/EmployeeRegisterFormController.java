package lk.ijse.fashionfiesta.controller;

import com.jfoenix.controls.JFXTextField;
import com.jfoenix.controls.JFXTreeTableView;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import lk.ijse.fashionfiesta.dto.Employee;
import lk.ijse.fashionfiesta.model.CustomerModel;
import lk.ijse.fashionfiesta.model.EmployeeAttendanceModel;
import lk.ijse.fashionfiesta.model.EmployeeModel;
import lk.ijse.fashionfiesta.tm.EmployeeTm;
import lk.ijse.fashionfiesta.utill.Navigation;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class EmployeeRegisterFormController implements Initializable {

    private static EmployeeRegisterFormController controller;

    @FXML
    public TableView EmployeeTbl;

    @FXML
    public TableColumn tblId;

    @FXML
    public TableColumn tblFirstName;
    @FXML
    public TableColumn tblLastName;

    @FXML
    public TableColumn tblCity;

    @FXML
    public TableColumn tblContact;
    public Text txtAllEmployee;
    public Text txtEmpAttendance;

    @FXML
    private JFXTextField txtSearch;
    private static EmployeeTm employeeTm;
    public EmployeeRegisterFormController employeeRegisterFormController;
    ObservableList<EmployeeTm> list= FXCollections.observableArrayList();
    public EmployeeRegisterFormController(){
        controller = this;
    }
    public static EmployeeRegisterFormController getInstance(){
        return controller;
    }
    public void btnEmployeeOnAction(MouseEvent mouseEvent) {
    }

    public void btnHomeOnAction(ActionEvent actionEvent) {
        try {
            Navigation.switchNavigation("AdminDashboardForm.fxml",actionEvent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void stockOnAction(ActionEvent actionEvent) {
        try {
            Navigation.switchNavigation("StockForm.fxml",actionEvent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void btnSupplierOnAction(ActionEvent actionEvent) {
        try {
            Navigation.switchNavigation("SupplierForm.fxml",actionEvent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void btnAddOnAction(ActionEvent actionEvent) {
        try {
            Navigation.popupNavigation("EmployeeAddForm.fxml" );
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void getAllIds() {
        try {
            ArrayList<String> list= EmployeeModel.getAllId();
            for (int i = 0; i < list.size(); i++) {
                setEmployeeData(list.get(i));
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    private void setEmployeeData(String id) {

        try {
            Employee employee = EmployeeModel.get(id);
            EmployeeTm tm=new EmployeeTm();
            tm.setEmp_Id(employee.getEmployee_id());
            tm.setFistName(employee.getEmployee_Fname());
            tm.setLastName(employee.getEmployee_Lname());
            tm.setCity(employee.getCity());
            tm.setContact(employee.getContact());
            tm.setLane(employee.getLane());
            tm.setRole(employee.getRole());
            tm.setStreet(employee.getStreet());
            list.add(tm);
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

    }

    public void loadDataTable() {
        list.clear();
        EmployeeTbl.getItems().clear();
        getAllIds();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        getAllIds();
        tblId.setCellValueFactory(new PropertyValueFactory<>("Emp_Id"));
        tblFirstName.setCellValueFactory(new PropertyValueFactory<>("fistName"));
        tblLastName.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        tblCity.setCellValueFactory(new PropertyValueFactory<>("city"));
        tblContact.setCellValueFactory(new PropertyValueFactory<>("contact"));
        EmployeeTbl.setItems(list);
        setEmployee();
        setEmpAttendance();
    }

    public void btnUpdateOnAction(ActionEvent actionEvent) {
        EmployeeUpdateFormController.getData(employeeTm);
        try {
            System.out.println();
            Navigation.popupNavigation("EmployeeUpdateForm.fxml");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void tblMouseClick(MouseEvent mouseEvent) {
        employeeTm = (EmployeeTm) EmployeeTbl.getSelectionModel().getSelectedItem();
    }

    public void btnEmployeeDelete(ActionEvent actionEvent) {
        try {
            boolean delete = EmployeeModel.remove(employeeTm.getEmp_Id());
            if (delete){
                EmployeeRegisterFormController.getInstance().loadDataTable();
                loadDataTable();
                new Alert(Alert.AlertType.CONFIRMATION,"SuccessFully Updated").show();
            }else {
                new Alert(Alert.AlertType.ERROR,"Error").show();
            }
        } catch (SQLException | ClassNotFoundException e) {
           e.printStackTrace();
        }
    }
    @FXML
    void searchKeyReleased(KeyEvent event) {
        EmployeeTbl.getItems().clear();
        list.clear();
        try {
            ArrayList<String> ids= EmployeeModel.getSearchIds(txtSearch.getText());
            for (int i = 0; i < ids.size(); i++) {
                setEmployeeData(ids.get(i));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
    public void setEmployee() {
        try {
            txtAllEmployee.setText(EmployeeModel.getEmployee());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
    public void setEmpAttendance() {
        try {
            txtEmpAttendance.setText(EmployeeAttendanceModel.getEmpAttendance());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    public void btnRepoartOnAction(ActionEvent actionEvent) {
        try {
            Navigation.switchNavigation("RepoartForm.fxml",actionEvent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
