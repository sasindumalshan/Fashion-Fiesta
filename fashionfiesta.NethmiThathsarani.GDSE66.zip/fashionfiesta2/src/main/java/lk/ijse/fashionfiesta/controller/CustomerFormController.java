package lk.ijse.fashionfiesta.controller;

import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import lk.ijse.fashionfiesta.dto.Customer;
import lk.ijse.fashionfiesta.model.CustomerModel;
import lk.ijse.fashionfiesta.model.SupplierOrderModel;
import lk.ijse.fashionfiesta.tm.CustomerTm;
import lk.ijse.fashionfiesta.utill.Navigation;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class CustomerFormController implements Initializable {

    private static CustomerFormController controller;
    public Text txtCustomer;
    private CustomerTm customerTm;


    @FXML
    private TableView CustomerTbl;

    @FXML
    private TableColumn tblCustId;

    @FXML
    private TableColumn tblFirstName;

    @FXML
    private TableColumn tblLastName;

    @FXML
    private TableColumn tblContactNumber;

    @FXML
    private TableColumn tblCity;

    @FXML
    private JFXTextField txtSearch;

    ObservableList<CustomerTm> list= FXCollections.observableArrayList();


    public CustomerFormController(){
        controller = this;
    }
    public static CustomerFormController getInstance(){
        return controller;
    }




    public void btnEmployeeOnAction(MouseEvent mouseEvent) {
    }

    public void btnHomeOnAction(ActionEvent actionEvent) {
        try {
            Navigation.switchNavigation("CashierDashboardForm.fxml",actionEvent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void btnSupplierOnAction(ActionEvent actionEvent) {
    }

    public void stockOnAction(ActionEvent actionEvent) {
    }

    public void btnOrderOnAction(ActionEvent actionEvent) {
        try {
            Navigation.switchNavigation("OrderForm.fxml",actionEvent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void btnStockOnAction(ActionEvent actionEvent) {
        try {
            Navigation.switchNavigation("CashierStockForm.fxml",actionEvent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void btnAttendanceOnAction(ActionEvent actionEvent) {
        try {
            Navigation.switchNavigation("EmployeeAttendanceForm.fxml",actionEvent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void btnCustomerOnAction(ActionEvent actionEvent) {
        try {
            Navigation.switchNavigation("CustomerForm.fxml",actionEvent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void btnstockOnAction(ActionEvent actionEvent) {
    }
    public void btnAddOnAction(ActionEvent actionEvent) throws IOException {
        Navigation.popupNavigation("CustomerAddForm.fxml");

    }

    public void btnUpdateOnAction(ActionEvent actionEvent) throws IOException {
        CustomerUpdateFormController.getData(customerTm);
        Navigation.popupNavigation("CustomerUpdateForm.fxml");
    }
    @FXML
    void deleteOnAction(ActionEvent event) {
        try {
            boolean delete = CustomerModel.remove(customerTm.getCust_id());
            if (delete){
                CustomerFormController.getInstance().loadDataTable();
                loadDataTable();
                new Alert(Alert.AlertType.CONFIRMATION,"SuccessFully Deleted").show();
            }else {
                new Alert(Alert.AlertType.ERROR,"Error").show();
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    public void loadDataTable() {
        list.clear();
        CustomerTbl.getItems().clear();
        getAllIds();
    }

    private void getAllIds() {
        try {
            ArrayList<String> list= CustomerModel.getAllId();
            for (int i = 0; i < list.size(); i++) {
                setCustomerData(list.get(i));
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    private void setCustomerData(String id) {
        try {
            Customer customer = CustomerModel.get(id);
            CustomerTm tm=new CustomerTm();
            tm.setCust_id(customer.getCustomer_Id());
            tm.setFistName(customer.getFirst_name());
            tm.setLastName(customer.getLast_name());
            tm.setCity(customer.getCity());
            tm.setContact_number(customer.getContact_number());
            tm.setLane(customer.getLane());
            tm.setStreet(customer.getStreet());
            list.add(tm);

            System.out.println(customer.getCity());
            System.out.println(customer.getLane());
            System.out.println(customer.getStreet());
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

    }
    public void tblMouseClick(MouseEvent mouseEvent){
        customerTm = (CustomerTm) CustomerTbl.getSelectionModel().getSelectedItem();
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        getAllIds();
        tblCustId.setCellValueFactory(new PropertyValueFactory<>("Cust_id"));
        tblFirstName.setCellValueFactory(new PropertyValueFactory<>("fistName"));
        tblLastName.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        tblContactNumber.setCellValueFactory(new PropertyValueFactory<>("contact_number"));
        tblCity.setCellValueFactory(new PropertyValueFactory<>("city"));
        CustomerTbl.setItems(list);
        setCustomer();
    }
    @FXML
    void searchKeyReleased(KeyEvent event) {
        CustomerTbl.getItems().clear();
        list.clear();
        try {
            ArrayList<String> ids= CustomerModel.getSearchIds(txtSearch.getText());
            for (int i = 0; i < ids.size(); i++) {
                setCustomerData(ids.get(i));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }


    public void setCustomer() {
        try {
            txtCustomer.setText(CustomerModel.getCustomer());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }


}
