package lk.ijse.fashionfiesta.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import lk.ijse.fashionfiesta.model.UserModel;
import lk.ijse.fashionfiesta.utill.Navigation;

import java.io.IOException;
import java.sql.SQLException;

public class LoginFormController {
    public Button btnLogin;
    public TextField txtUserName;
    public TextField txtPassword;

    @FXML
    void LoginOnAction(ActionEvent event) throws IOException {
        try {
            if (UserModel.checkUsernameAndPassword(txtUserName.getText(),txtPassword.getText()).equals("Admin")) {
                Navigation.switchNavigation("AdminDashboardForm.fxml", event);
            } else if (UserModel.checkUsernameAndPassword(txtUserName.getText(),txtPassword.getText()).equals("Cashier")) {
                Navigation.switchNavigation("CashierDashboardForm.fxml", event);
            } else {
                new Alert(Alert.AlertType.ERROR, "Error").show();
            }
        } catch (SQLException | ClassNotFoundException | IOException e) {
            throw new RuntimeException(e);
        }
    }
}
