package lk.ijse.fashionfiesta.controller;

import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.fxml.FXML;
import  javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import lk.ijse.fashionfiesta.dto.Employee;
import lk.ijse.fashionfiesta.dto.Supplier;
import lk.ijse.fashionfiesta.model.SupplierModel;
import lk.ijse.fashionfiesta.dto.Supplier;
import lk.ijse.fashionfiesta.model.SupplierModel;
import lk.ijse.fashionfiesta.utill.Navigation;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.net.URL;
import java.sql.ResultSet;

public class SupplierAddController implements Initializable {

    @FXML
    private JFXTextField txtSupId;

    @FXML
    private JFXTextField txtFirstName;

    @FXML
    private JFXTextField txtLastName;

    @FXML
    private JFXTextField txtStreet;

    @FXML
    private JFXTextField txtCity;

    @FXML
    private JFXTextField txtLane;

    @FXML
    private JFXTextField txtContact;

    private ResultSet set;
    private ObservableList<Supplier> data;

    public void addOnAction(ActionEvent actionEvent) {
        Supplier supplier = new Supplier();
        supplier.setSupplier_id(txtSupId.getText());
        supplier.setSupplier_Fname(txtFirstName.getText());
        supplier.setSupplier_Lname(txtLastName.getText());
        supplier.setStreet(txtStreet.getText());
        supplier.setCity(txtCity.getText());
        supplier.setLane(txtLane.getText());
        supplier.setContact(txtContact.getText());

        try {
            boolean add = SupplierModel.addSupplier(supplier);
            if (add){
                SupplierFormController.getInstance().loadDataTable();
                new Alert(Alert.AlertType.CONFIRMATION,"SuccessFully Added").show();
                Navigation.close(actionEvent);
            }else {
                new Alert(Alert.AlertType.CONFIRMATION,"Error Added").show();
            }

        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}

