package lk.ijse.fashionfiesta.controller;

import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import lk.ijse.fashionfiesta.dto.Supplier;
import lk.ijse.fashionfiesta.model.CustomerModel;
import lk.ijse.fashionfiesta.model.SupplierModel;
import lk.ijse.fashionfiesta.model.SupplierOrderModel;
import lk.ijse.fashionfiesta.tm.SupplierTm;
import lk.ijse.fashionfiesta.utill.Navigation;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class SupplierFormController implements Initializable {

    private static SupplierFormController controller;
    public TableColumn supplierCol;

    public TableColumn tblId;
    public Text txtSupplier;
    public Text txtSupOrder;

    @FXML
    private JFXTextField txtSearch;
    @FXML
    private ToggleGroup supplier;

    @FXML
    private TableView<SupplierTm> EmployeeTbl;

    @FXML
    private TableColumn<?, ?> tblFirstName;

    @FXML
    private TableColumn<?, ?> tblLastName;

    @FXML
    private TableColumn<?, ?> tblCity;

    @FXML
    private TableColumn<?, ?> tblContact;
    private static SupplierTm supplierTm;

    public EmployeeRegisterFormController supplierRegisterFormController;
    ObservableList<SupplierTm> list= FXCollections.observableArrayList();
    public SupplierFormController(){
        controller = this;
    }
    public static SupplierFormController getInstance(){
        return controller;
    }

    public void btnSupplierOnAction(MouseEvent mouseEvent) {

    }



        public void btnHomeOnAction(ActionEvent actionEvent) {
            try {
                Navigation.switchNavigation("AdminDashboardForm.fxml", actionEvent);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void btnEmployeeOnAction(ActionEvent actionEvent) throws IOException {
            Navigation.switchNavigation("EmployeeRegisterForm.fxml", actionEvent);
        }

        public void stockOnAction(ActionEvent actionEvent) {
            try {
                Navigation.switchNavigation("StockForm.fxml", actionEvent);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void btnAddOnAction(ActionEvent actionEvent) {
            try {
                Navigation.popupNavigation("SupplierAdd.fxml");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    private void getAllIds() {
        try {
            ArrayList<String> list= SupplierModel.getAllId();
            for (int i = 0; i < list.size(); i++) {
                setSupplierData(list.get(i));
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    private void setSupplierData(String id) {
        try {
            Supplier supplier = SupplierModel.get(id);
            SupplierTm tm=new SupplierTm();

            System.out.println(supplier.toString());
            System.out.println(tm.toString());

            tm.setSup_Id(supplier.getSupplier_id());
            tm.setFistName(supplier.getSupplier_Fname());
            tm.setLastName(supplier.getSupplier_Lname());
            tm.setCity(supplier.getCity());
            tm.setContact(supplier.getContact());
            tm.setLane(supplier.getLane());
            tm.setStreet(supplier.getStreet());
            System.out.println(supplier.getSupplier_id());
            list.add(tm);
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

    }

    public void loadDataTable() {
        list.clear();
        EmployeeTbl.getItems().clear();
        getAllIds();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        getAllIds();
        tblId.setCellValueFactory(new PropertyValueFactory<>("Sup_Id"));
        tblFirstName.setCellValueFactory(new PropertyValueFactory<>("fistName"));
        tblLastName.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        tblCity.setCellValueFactory(new PropertyValueFactory<>("city"));
        tblContact.setCellValueFactory(new PropertyValueFactory<>("contact"));
        EmployeeTbl.setItems(list);
        setSupplier();
        setSupOrder();
    }



        public void tblMouseClick(MouseEvent mouseEvent) {
            supplierTm = (SupplierTm) EmployeeTbl.getSelectionModel().getSelectedItem();
        }



        public void btnUpdateOnAction(ActionEvent actionEvent) {
            SupplierUpdateFormController.getData(supplierTm);
            try {
                System.out.println();
                Navigation.popupNavigation("SupplierUpdateForm.fxml");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    public void btnDeleteOnAction(ActionEvent actionEvent) {
        try {
            boolean delete = SupplierModel.remove(supplierTm.getSup_Id());
            if (delete){
                SupplierFormController.getInstance().loadDataTable();
                loadDataTable();
                new Alert(Alert.AlertType.CONFIRMATION,"SuccessFully Updated").show();
            }else {
                new Alert(Alert.AlertType.ERROR,"Error").show();
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    public void btnNewOrdersOnAction(ActionEvent actionEvent) {
        try {
            Navigation.popupNavigation("SupplierOrderForm.fxml");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @FXML
    void searchKeyReleased(KeyEvent event) {
        EmployeeTbl.getItems().clear();
        list.clear();
        try {
            ArrayList<String> ids= SupplierModel.getSearchIds(txtSearch.getText());
            for (int i = 0; i < ids.size(); i++) {
                setSupplierData(ids.get(i));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
    public void setSupplier() {
        try {
            txtSupplier.setText(SupplierModel.getSupplier());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    public void setSupOrder() {
        try {
            txtSupOrder.setText(SupplierOrderModel.getSupplierOrder());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }


}

