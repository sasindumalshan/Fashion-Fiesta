package lk.ijse.fashionfiesta.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.layout.Pane;
import lk.ijse.fashionfiesta.db.DBConnection;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.view.JasperViewer;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;

public class RepoartFormController {
    public Pane pane;

    public void btnEmployeeOnAction(ActionEvent actionEvent) {

    }

    public void btnSupplierOnAction(ActionEvent actionEvent) {

    }

    public void stockOnAction(ActionEvent actionEvent) {

    }

    public void btnEmployeeAttendanceOnAction(ActionEvent actionEvent) {
        try {
            JasperReport jasperReport = JasperCompileManager.compileReport("C:\\Users\\GCV\\Downloads\\fashionfiestazzzzzzz\\fashionfiesta\\src\\main\\resources\\Report\\EmployeeAttendance.jrxml");
            JRDataSource jrDataSource = new JRBeanCollectionDataSource(Arrays.asList(new Object()));

            HashMap hm = new HashMap();


            Connection connection = DBConnection.getInstance().getConnection();
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, hm, connection);
            JasperViewer.viewReport(jasperPrint, false);
//
        } catch (JRException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public void btnSupplierOrderOnAction(ActionEvent actionEvent) {
    }

    public void btnCustomerOrderOnAction(ActionEvent actionEvent) {
    }

    public void btnSalaryOnAction(ActionEvent actionEvent) {
        pane.getChildren().clear();
        FXMLLoader loader = new FXMLLoader(RepoartFormController.class.getResource("/view/SalaryForm.fxml"));
        Parent root = null;
        try {
            root = loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        pane.getChildren().add(root);
    }
}
