package lk.ijse.fashionfiesta.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import lk.ijse.fashionfiesta.model.CustomerModel;
import lk.ijse.fashionfiesta.tm.CustomerTm;
import lk.ijse.fashionfiesta.utill.Navigation;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class CustomerUpdateFormController implements Initializable {
    private static CustomerTm customerTm;

    @FXML
    private TextField txtFirstName;

    @FXML
    private TextField txtLastName;

    @FXML
    private TextField txtContactNumber;

    @FXML
    private TextField txtStreet;

    @FXML
    private TextField txtCity;

    @FXML
    private TextField txtLane;


    public static void getData(CustomerTm customerTm) {
        CustomerUpdateFormController.customerTm = customerTm;
        System.out.println(CustomerUpdateFormController.customerTm.getCity());

    }

    @FXML
    public void updateOnAction(ActionEvent actionEvent) {
        customerTm.setFistName(txtFirstName.getText());
        customerTm.setLastName(txtLastName.getText());
        customerTm.setStreet(txtStreet.getText());
        customerTm.setCity(txtCity.getText());
        customerTm.setLane(txtLane.getText());
        customerTm.setContact_number(txtContactNumber.getText());

        try {
            boolean update = CustomerModel.update(
                    customerTm
            );
            if (update) {
                CustomerFormController.getInstance().loadDataTable();
                new Alert(Alert.AlertType.CONFIRMATION, "SuccessFully Updated").show();
                Navigation.close(actionEvent);
            } else {
                new Alert(Alert.AlertType.CONFIRMATION, "Error").show();
            }
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        txtFirstName.setText(CustomerUpdateFormController.customerTm.getFistName());
        txtLastName.setText(CustomerUpdateFormController.customerTm.getLastName());
        txtCity.setText(CustomerUpdateFormController.customerTm.getCity());
        txtContactNumber.setText(CustomerUpdateFormController.customerTm.getContact_number());
        txtLane.setText(CustomerUpdateFormController.customerTm.getLane());
        txtStreet.setText(CustomerUpdateFormController.customerTm.getStreet());
    }

}

