package lk.ijse.fashionfiesta.controller;

import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import lk.ijse.fashionfiesta.dto.OrderTmDto;
import lk.ijse.fashionfiesta.dto.SupplierOrder;
import lk.ijse.fashionfiesta.dto.SupplierOrderDetails;
import lk.ijse.fashionfiesta.model.StockModel;
import lk.ijse.fashionfiesta.model.SupplierModel;
import lk.ijse.fashionfiesta.model.SupplierOrderDetailsModel;
import lk.ijse.fashionfiesta.model.SupplierOrderModel;
import lk.ijse.fashionfiesta.tm.SupplierOrderTm;
import lk.ijse.fashionfiesta.utill.DateTimeUtil;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class SupplierOrderFormController implements Initializable {

    @FXML
    private JFXTextField txtSearch;

    public TableColumn coltemId;
    public TableColumn colSupplierOrderId;
    public TableColumn colDate;
    public TableColumn colPrice;
    public TableColumn colQty;
    public TableColumn colPayment;
    public JFXTextField supplierOrderId;

    public JFXTextField price;
    public JFXTextField qty;
    public JFXComboBox supplierId;
    public JFXComboBox itemId;
    public TableView tblSupplierOrder;

    ObservableList<SupplierOrderTm> list = FXCollections.observableArrayList();

    public void btnAddOnAction(ActionEvent actionEvent) {
        SupplierOrder supplierOrder = new SupplierOrder();
        supplierOrder.setSupplier_id(String.valueOf(supplierId.getValue()));
        supplierOrder.setSupplier_order_id(supplierOrderId.getText());
        supplierOrder.setSupplier_order_date(DateTimeUtil.dateNow());
        supplierOrder.setSupplier_order_time(DateTimeUtil.timeNow());
        supplierOrder.setPayment(String.valueOf(setTotalPayemnt()));

        SupplierOrderDetails details = new SupplierOrderDetails();
        details.setSupplier_order_id(supplierOrderId.getText());
        details.setItem_id(String.valueOf(itemId.getValue()));
        details.setQuantity(qty.getText());
        details.setPrice(price.getText());

        if (SupplierOrderModel.placeOrder(supplierOrder, details)) {
            //new Alert(Alert.AlertType.CONFIRMATION,"Successfully Added").show();
            loadDataTable();
        } else {
            new Alert(Alert.AlertType.ERROR, "Error").show();
        }
    }

    public void loadAllSupplierId(){
        list.clear();
        try {
            ArrayList<String> ids = SupplierOrderModel.getAll();

            for (int i = 0; i < ids.size(); i++) {
                setSupplierData(ids.get(i));
//                System.out.println(ids.get(i));
            }
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }


    private void setSupplierData(String id) {
        System.out.println("ID : "+id);
        try {
            OrderTmDto orderTmDto = SupplierOrderDetailsModel.get(id);
            SupplierOrderTm supplierOrderTm = new SupplierOrderTm();

            if (orderTmDto.getItem_id()!=null){
                supplierOrderTm.setItem_id(orderTmDto.getItem_id());
                supplierOrderTm.setSupplier_order_id(orderTmDto.getSupplier_order_id());
                supplierOrderTm.setSupplier_order_date(orderTmDto.getSupplier_order_date());
                supplierOrderTm.setPrice(orderTmDto.getPrice());
                supplierOrderTm.setQuantity(orderTmDto.getQuantity());
                supplierOrderTm.setPayment(orderTmDto.getPayment());
                list.addAll(supplierOrderTm);

                System.out.println(supplierOrderTm.toString());

            }



        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setItemId();
        setSupplierId();
        loadAllSupplierId();
//        setSupplierData();
        coltemId.setCellValueFactory(new PropertyValueFactory<>("item_id"));
        colSupplierOrderId.setCellValueFactory(new PropertyValueFactory<>("supplier_order_id"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("Supplier_order_date"));
        colPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
        colQty.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        colPayment.setCellValueFactory(new PropertyValueFactory<>("payment"));
        tblSupplierOrder.setItems(list);
    }

    public void setItemId() {
        try {
            ArrayList<String> ids = StockModel.getAllId();
            itemId.getItems().addAll(ids);
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public void setSupplierId() {
        try {
            ArrayList<String> ids = SupplierModel.getAllId();
            supplierId.getItems().addAll(ids);
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public double setTotalPayemnt() {
        double total = 0.0;
        total = Double.parseDouble(qty.getText()) * Double.parseDouble(price.getText());
        return total;
    }

    public void loadDataTable() {
        list.clear();
        tblSupplierOrder.getItems().clear();
        loadAllSupplierId();
//        setSupplierData();
    }
    @FXML
    void searchKeyReleased(KeyEvent event) {
        tblSupplierOrder.getItems().clear();
        list.clear();
        try {
            ArrayList<String> ids= SupplierOrderModel.getSearchIds(txtSearch.getText());
            for (int i = 0; i < ids.size(); i++) {
                setSupplierData(ids.get(i));
            }

           /* if (txtSearch.getText().isEmpty()){
                ids.clear();
            }

            if (ids.size()<=0&&txtSearch.getText().isEmpty()){
                loadAllSupplierId();
            }*/
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
}
