package lk.ijse.fashionfiesta.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import lk.ijse.fashionfiesta.model.CustomerOrderModel;
import lk.ijse.fashionfiesta.model.EmployeeModel;
import lk.ijse.fashionfiesta.model.SupplierOrderModel;
import lk.ijse.fashionfiesta.utill.Navigation;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class CashierDashboardFormController implements Initializable {

    public Label txtEmployee;
    public Label txtCustOrder;

    @FXML
    void btnAttendanceOnAction(ActionEvent event) {
        try {
            Navigation.switchNavigation("EmployeeAttendanceForm.fxml",event);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void btnCustomerOnAction(ActionEvent event) {
        try {
            Navigation.switchNavigation("CustomerForm.fxml",event);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void btnOrderOnAction(ActionEvent event) {
        try {
            Navigation.switchNavigation("OrderForm.fxml",event);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @FXML
    void btnStockOnAction(ActionEvent event) {
        try {
            Navigation.switchNavigation("CashierStockForm.fxml",event);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void setEmpCount() {
        try {
            txtEmployee.setText(EmployeeModel.getEmpCount());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    public void setCustOrder() {
        try {
            txtCustOrder.setText(CustomerOrderModel.getCustOrder());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setEmpCount();
        setCustOrder();
    }
}
