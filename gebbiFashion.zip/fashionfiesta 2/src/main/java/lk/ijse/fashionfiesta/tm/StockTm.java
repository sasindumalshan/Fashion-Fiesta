package lk.ijse.fashionfiesta.tm;

import javafx.scene.control.Button;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class StockTm {
    private String itemId;
    private String itemName;
    private String price;
    private String model_color;
    private String category;



//    public StockTm() {
//    }
//
//    public StockTm(String item_Id, String item_Name, String price, String model_color, String category, Button option, Button view) {
//        Item_Id = item_Id;
//        this.Item_Name = item_Name;
//        this.price = price;
//        this.model_color = model_color;
//        this.category = category;
//    }
//
//    public String getItem_Id() {
//        return Item_Id;
//    }
//
//    public  void setItem_Id(String item_Id) {Item_Id = item_Id;}
//
//    public String getItem_Name() {return getItem_Name(); }
//
//    public void setItem_Name(String item_Name) {
//        this.Item_Name = item_Name;
//    }
//
//    public String getModel_color() {
//        return model_color;
//    }
//
//    public void setModel_color(String color) {
//        this.model_color = color;
//    }
//
//    public String getPrice() {
//        return price;
//    }
//
//    public void setPrice(String price) {
//        this.price = price;
//    }
//
//    public String getCategory() {
//        return category;
//    }
//
//    public void setCategory(String category) {
//        this.category = category;
//    }


}
