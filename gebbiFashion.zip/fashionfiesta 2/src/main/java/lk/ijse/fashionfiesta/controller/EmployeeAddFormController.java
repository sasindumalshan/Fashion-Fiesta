package lk.ijse.fashionfiesta.controller;

import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.controls.RecursiveTreeItem;
import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TreeItem;
import javafx.scene.control.cell.TreeItemPropertyValueFactory;
import lk.ijse.fashionfiesta.dto.Employee;
import lk.ijse.fashionfiesta.model.EmployeeModel;
import lk.ijse.fashionfiesta.utill.Navigation;

import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class EmployeeAddFormController implements Initializable {

    public JFXComboBox txtRole;
    @FXML
    private JFXTextField txtCustId;

    @FXML
    private JFXTextField txtFirstName;

    @FXML
    private JFXTextField txtLastName;

    @FXML
    private JFXTextField txtStreet;

    @FXML
    private JFXTextField txtCity;

    @FXML
    private JFXTextField txtLane;

    @FXML
    private JFXTextField txtContact;

    private ResultSet set;
    private ObservableList<Employee> data;

    public void addOnAction(ActionEvent actionEvent) {
        Employee employee = new Employee();
        employee.setEmployee_id(txtCustId.getText());
        employee.setEmployee_Fname(txtFirstName.getText());
        employee.setEmployee_Lname(txtLastName.getText());
        employee.setStreet(txtStreet.getText());
        employee.setCity(txtCity.getText());
        employee.setLane(txtLane.getText());
        employee.setRole(getRole());
        employee.setContact(txtContact.getText());

        try {
            boolean add = EmployeeModel.addEmployee(employee);
            if (add){
                EmployeeRegisterFormController.getInstance().loadDataTable();
                new Alert(Alert.AlertType.CONFIRMATION,"SuccessFully Added").show();
                Navigation.close(actionEvent);
            }else {
                new Alert(Alert.AlertType.CONFIRMATION,"Error Added").show();
            }

        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    public void setDataInComboBox() {
        ArrayList<String> role = new ArrayList<>();
        role.add("Admin");
        role.add("Cashier");
        role.add("Salsmen");
        role.add("Other");
        txtRole.getItems().addAll(role);
    }
    public String getRole(){
        return String.valueOf(txtRole.getSelectionModel().getSelectedItem());
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setDataInComboBox();
    }
}
