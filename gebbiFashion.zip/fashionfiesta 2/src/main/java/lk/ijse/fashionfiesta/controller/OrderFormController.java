package lk.ijse.fashionfiesta.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.text.Text;
import lk.ijse.fashionfiesta.dto.*;
import lk.ijse.fashionfiesta.model.*;
import lk.ijse.fashionfiesta.tm.CustomerOrderTm;
import lk.ijse.fashionfiesta.tm.SupplierOrderTm;
import lk.ijse.fashionfiesta.utill.DateTimeUtil;
import lk.ijse.fashionfiesta.utill.Navigation;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class OrderFormController implements Initializable {

    public TableView tblSupplierOrder;
    public TableColumn coltemId;
    public TableColumn colCustomerOrderId;
    public TableColumn colDate;
    public TableColumn colPrice;
    public TableColumn colQty;
    public TableColumn colPayment;
    public JFXComboBox CustomerId;
    public JFXComboBox itemId;
    public JFXTextField CustomerOrderId;
    public JFXTextField price;
    public JFXTextField qty;
    public JFXButton btnDone;
    public JFXButton btnAdd;
    public Text txtTotal;

    @FXML
    private JFXTextField txtSearch;

    ObservableList<CustomerOrderTm> list = FXCollections.observableArrayList();

    public void btnstockOnAction(ActionEvent actionEvent) {
        try {
            Navigation.switchNavigation("CashierStockForm.fxml",actionEvent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void btnSupplierOnAction(ActionEvent actionEvent) {
        
    }

    public void btnCustomerOnAction(ActionEvent actionEvent) {
        try {
            Navigation.switchNavigation("CustomerForm.fxml",actionEvent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void btnHomeOnAction(ActionEvent actionEvent) {
        try {
            Navigation.switchNavigation("CashierDashboardForm.fxml",actionEvent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void btnAttendanceOnAction(ActionEvent actionEvent) {
        try {
            Navigation.switchNavigation("EmployeeAttendanceForm.fxml",actionEvent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void btnAddOnAction(ActionEvent actionEvent) {
        btnDone.setDisable(false);
   txtTotal.setText(String.valueOf(Double.parseDouble(price.getText()) * Double.parseDouble(qty.getText())));
    }

    public void loadAllCustomerId(){
        try {
            ArrayList<String> ids = CustomerOrderModel.getAll();

            for (int i = 0; i < ids.size(); i++) {
                setCustomerData(ids.get(i));
                System.out.println(ids.get(i));
            }
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    private void setCustomerData(String id) {
        try {
            CusOrderTmDto cusOrderTmDto = CustomerOrderDetailsModel.get(id);
            CustomerOrderTm customerOrderTm = new CustomerOrderTm();

            customerOrderTm.setItem_id(cusOrderTmDto.getItem_id());
            customerOrderTm.setCustomer_order_id(cusOrderTmDto.getCustomer_order_id());
            customerOrderTm.setCustomer_order_date(cusOrderTmDto.getCustomer_order_date());
            customerOrderTm.setPrice(cusOrderTmDto.getPrice());
            customerOrderTm.setQuantity(cusOrderTmDto.getQuantity());
            customerOrderTm.setPayment(cusOrderTmDto.getPayment());
            list.addAll(customerOrderTm);
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setItemId();
        setCustomerId();
        loadAllCustomerId();
        btnDone.setDisable(true);
//        setSupplierData();
        coltemId.setCellValueFactory(new PropertyValueFactory<>("item_id"));
        colCustomerOrderId.setCellValueFactory(new PropertyValueFactory<>("customer_order_id"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("Customer_order_date"));
        colPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
        colQty.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        colPayment.setCellValueFactory(new PropertyValueFactory<>("payment"));
        tblSupplierOrder.setItems(list);
    }


    public void setItemId() {
        try {
            ArrayList<String> ids = StockModel.getAllId();
            itemId.getItems().addAll(ids);
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public void setCustomerId() {
        try {
            ArrayList<String> ids = CustomerModel.getAllId();
            CustomerId.getItems().addAll(ids);
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public void loadDataTable() {
        list.clear();
        tblSupplierOrder.getItems().clear();
        loadAllCustomerId();
//        setSupplierData();
    }

    @FXML
    void searchKeyReleased(KeyEvent event) {
        tblSupplierOrder.getItems().clear();
        list.clear();
        try {
            ArrayList<String> ids= CustomerOrderModel.getSearchIds(txtSearch.getText());
            for (int i = 0; i < ids.size(); i++) {
                setCustomerData(ids.get(i));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    public void btnDoneOnAction(ActionEvent actionEvent) {
        CustomerOrder customerOrder = new CustomerOrder();
        customerOrder.setCustomer_id(String.valueOf(CustomerId.getValue()));
        customerOrder.setCustomer_order_id(CustomerOrderId.getText());
        customerOrder.setCustomer_order_date(DateTimeUtil.dateNow());
        customerOrder.setCustomer_order_time(DateTimeUtil.timeNow());
        customerOrder.setPayment(txtTotal.getText());

        CustomerOrderDetails details = new CustomerOrderDetails();
        details.setCustomer_order_id(CustomerOrderId.getText());
        details.setItem_id(String.valueOf(itemId.getValue()));
        details.setQuantity(qty.getText());
        details.setPrice(price.getText());

        if (CustomerOrderModel.placeOrder(customerOrder, details)) {
            new Alert(Alert.AlertType.CONFIRMATION,"Successfully Added").show();
            loadDataTable();
        } else {
            new Alert(Alert.AlertType.ERROR, "Error").show();
        }
    }

    public void cmbItemIdOnAction(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        Stock stock = StockModel.get(String.valueOf(itemId.getValue()));
        price.setText(String.valueOf(stock.getPrice()));
    }
}


