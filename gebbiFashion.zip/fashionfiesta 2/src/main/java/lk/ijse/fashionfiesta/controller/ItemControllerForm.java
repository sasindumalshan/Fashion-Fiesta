package lk.ijse.fashionfiesta.controller;

import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import lk.ijse.fashionfiesta.dto.Stock;
import lk.ijse.fashionfiesta.model.CustomerModel;
import lk.ijse.fashionfiesta.model.StockModel;
import lk.ijse.fashionfiesta.tm.StockTm;
import lk.ijse.fashionfiesta.utill.Navigation;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;


public class ItemControllerForm implements Initializable {

    private static ItemControllerForm controller;
    public TableColumn tblItemName;
    public TableColumn tblItemPrice;
    public TableColumn tblItemModelColor;
    public TableColumn tblCatagory;
    public Text txtStock;

    @FXML
    private TableView<StockTm> EmployeeTbl;

    @FXML
    private TableColumn tblId;

    @FXML
    private JFXTextField txtSearch;

    private static StockTm stockTm;

    ObservableList<StockTm> list= FXCollections.observableArrayList();
    public ItemControllerForm(){ controller = this;}
    public static ItemControllerForm getInstance(){
        return controller;
    }

    public void stockOnAction(ActionEvent actionEvent) {
    }


    public void btnUpdateOnAction(ActionEvent actionEvent) {
        StockUpdateFormController.getData(stockTm);
        try {
            System.out.println();
            Navigation.popupNavigation("StockUpdateForm.fxml");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void btnDeleteOnAction(ActionEvent actionEvent) {

            try {
                boolean delete = StockModel.remove(stockTm.getItemId());
                if (delete){
                    ItemControllerForm.getInstance().loadDataTable();
                    loadDataTable();
                    new Alert(Alert.AlertType.CONFIRMATION,"SuccessFully Updated").show();
                }else {
                    new Alert(Alert.AlertType.ERROR,"Error").show();
                }
            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();
            }


    }

        public void btnEmployeeOnAction(ActionEvent actionEvent) {
            try {
                Navigation.switchNavigation("EmployeeRegisterForm.fxml", actionEvent);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void btnSupplierOnAction(ActionEvent actionEvent) {
            try {
                Navigation.switchNavigation("SupplierForm.fxml", actionEvent);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void stockOnAction(MouseEvent mouseEvent) {
        }

        public void btnHomeOnAction(ActionEvent actionEvent) {
            try {
                Navigation.switchNavigation("AdminDashboardForm.fxml", actionEvent);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void btnAddOnAction(ActionEvent actionEvent) {
            try {
                Navigation.popupNavigation("StockAddForm.fxml");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        private void getAllIds() {
            try {
                ArrayList<String> list= StockModel.getAllId();
                for (int i = 0; i < list.size(); i++) {
                    setStockData(list.get(i));
                }

            } catch (SQLException | ClassNotFoundException throwables) {
                throwables.printStackTrace();
            }
        }

        private void setStockData(String id) {

            try {
                Stock stock = StockModel.get(id);
                StockTm tm=new StockTm();
                tm.setItemId(stock.getItem_id());
                tm.setItemName(stock.getItem_name());
                tm.setPrice(String.valueOf(stock.getPrice()));
                tm.setModel_color(stock.getModel_color());
                tm.setCategory(stock.getCategory());
                list.add(tm);
                System.out.println(tm.getItemId());
            } catch (SQLException | ClassNotFoundException e) {
                throw new RuntimeException(e);
            }

        }
        public void loadDataTable() {
            list.clear();
            EmployeeTbl.getItems().clear();
            getAllIds();
        }

        @Override
        public void initialize(URL location, ResourceBundle resources) {
            getAllIds();
            tblId.setCellValueFactory(new PropertyValueFactory<>("itemId"));
            tblItemName.setCellValueFactory(new PropertyValueFactory<>("itemName"));
            tblItemPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
            tblItemModelColor.setCellValueFactory(new PropertyValueFactory<>("model_color"));
            tblCatagory.setCellValueFactory(new PropertyValueFactory<>("category"));
            EmployeeTbl.setItems(list);
            setStock();
        }

        public void tblMouseClick(MouseEvent mouseEvent) {
            stockTm =  EmployeeTbl.getSelectionModel().getSelectedItem();
        }
    @FXML
    void searchKeyReleased(KeyEvent event) {
        EmployeeTbl.getItems().clear();
        list.clear();
        try {
            ArrayList<String> ids= StockModel.getSearchIds(txtSearch.getText());
            for (int i = 0; i < ids.size(); i++) {
                setStockData(ids.get(i));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    public void searchKeyRelesed(ActionEvent actionEvent) {
    }


    public void setStock() {
        try {
            txtStock.setText(StockModel.getStock());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
}

