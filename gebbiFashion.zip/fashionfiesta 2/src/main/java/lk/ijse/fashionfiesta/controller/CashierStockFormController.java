package lk.ijse.fashionfiesta.controller;

import javafx.event.ActionEvent;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import lk.ijse.fashionfiesta.utill.Navigation;

import java.io.IOException;

public class CashierStockFormController {

    public TableView tblStockView;
    public TableColumn colItemId;
    public TableColumn colItemName;
    public TableColumn colPrice;
    public TableColumn colModelColour;
    public TableColumn colCategory;

    public void btnHomeOnAction(ActionEvent actionEvent) {
        try {
            Navigation.switchNavigation("CashierDashboardForm.fxml",actionEvent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void btnCustomerOnAction(ActionEvent actionEvent) {
        try {
            Navigation.switchNavigation("CustomerForm.fxml",actionEvent);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void btnOrdersOnAction(ActionEvent actionEvent) {
        try {
            Navigation.switchNavigation("OrderForm.fxml",actionEvent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void btnAttendanceOnAction(ActionEvent actionEvent) {
        try {
            Navigation.switchNavigation("EmployeeAttendanceForm.fxml",actionEvent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
